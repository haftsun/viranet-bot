# Entry point of ViraNet Bot
